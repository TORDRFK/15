#include <bdd240.h>
#include <blc150.h>
#include <blc200.h>
#include <dmd150.h>
#include <mas001.h>
#include <sbd10.h>
#include <sbd14.h>

## 테스트 방법

* 노브를 돌리면 속도가 조절 됩니다.
* 빨간 버튼을 누르면 모터가 멈춥니다.
* 파란 버튼을 누르면 모터가 반대 방향으로 회전합니다.